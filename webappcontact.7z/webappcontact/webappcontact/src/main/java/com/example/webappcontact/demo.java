package com.example.webappcontact;

public class demo {
private 	String Name;
private  String Email;
private String Pnum;
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getPnum() {
	return Pnum;
}
public void setPnum(String pnum) {
	Pnum = pnum;
}

}
